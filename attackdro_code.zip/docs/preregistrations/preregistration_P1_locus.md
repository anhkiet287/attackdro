# Pre-registration — P1: LOCUS pilot (alignment term computed on the classifier-facing features)

**Written before arm E exists and before any P1 number is computed.** Committed 2026-07-23, before
any line of the training or evaluation code for this pilot was written. Report-regardless: whichever
way the numbers fall, they are reported as measured, and this document is not edited afterwards
except to append the outcome pointer in §9.

This is a **PILOT** on a **REDUCED evaluation harness**. Its numbers are **never** compared to any
12-attack number in the paper. See §6.

## 1. Question

Two established results motivate this pilot, and neither is revised by it:

- **T2** (pre-registered, `preregistration_T2_representation_geometry.md`): in the encoder features
  `f` that the linear classifier actually consumes, the CLAMP term moves adversarial representations
  **further** from clean, not closer — all six relative-movement values positive, CIs excluding zero,
  on both bases.
- **T2b** (pre-registered, `preregistration_T2b_head_space.md`): the alignment the loss optimises
  lives in `h = normalize(head(f))`, a projection head that is **discarded at evaluation**; and it is
  not even achieved there (P1 falsified: `d_h` is 2–6× looser than `d_f`).

The term therefore acts on a space the classifier never reads. **P1 changes the LOCUS of the loss and
nothing else**: both CLAMP terms are computed on `f` instead of on `normalize(head(f))`. The question
is whether alignment enforced at the classifier-facing features behaves differently.

P1 does **not** test whether CLAMP is a good method, does not revise T2/T2b, and does not produce a
number that enters the paper's tables.

## 2. Arms and contrasts, fixed in advance

| slot | arm | locus of glue + scaffold | status |
|---|---|---|---|
| new | **E** | `normalize(f)` — pooled 512-d post-ReLU encoder output | to be trained by this pilot |
| existing | **M1a** | `normalize(head(f))` (h) | already trained, seed 0 |
| existing | **M0** | term off (matched control) | already trained, seed 0 |

- **PRIMARY contrast: `E − M0`** — does a locus-corrected term help at all?
- **SECONDARY contrast: `E − M1a`** — does the locus matter?

Arm E is seed 0, matching both existing arms.

## 3. Metrics, fixed in advance

- **PRIMARY: union over the three APGD-CE blocks at 1k**, at `val_best` weights. Union = per-example
  AND across `apgd_ce_linf`, `apgd_ce_l2`, `apgd_ce_l1`.
- **SECONDARY, pre-specified: the `linf` block**, on the grounds established elsewhere in this
  project that union at this triple is ℓ∞-bound.

No other metric is promoted to primary or secondary after the fact. Clean accuracy and the ℓ₂ / ℓ₁
blocks are reported for completeness but are **descriptive**.

## 4. The asymmetric reading rule — the point of this pre-registration

Arm E differs from M1a in **TWO** ways, not one:

1. the **locus** changes (`f` instead of `h`); and
2. the **push branch loses its negative range**. `f` is non-negative after the final ReLU
   (`F.relu(b.bn(out))`, `c5_fromscratch.py:78`), so cosine on `f` is confined to **[0, 1]** and
   pairs cannot be driven past orthogonality. The scaffold term can push a pair to cos = 0 and no
   further.

This asymmetry is **measured**, not assumed. From `results/analysis/T2_geometry/t2g_prerelu.json`,
cosine between randomly paired different images:

| space | mean | min | fraction < 0 |
|---|---|---|---|
| `h` (M1a, trained head) | +0.0174 | −0.2728 | **0.5720** |
| `f` post-ReLU (M1a) | +0.2459 | +0.0513 | **0.0000** |

So in `h` the repulsion term has a genuinely signed range and over half of random pairs already sit
below zero; in `f` **no** pair can. Arm E's push branch is therefore structurally weaker than M1a's,
independently of the locus.

**Consequently the `E − M1a` contrast is read asymmetrically, and this is fixed now:**

| outcome of `E − M1a` (primary metric) | reading |
|---|---|
| significantly **positive** | **evidence for the locus account** — E wins *despite* the narrower push range |
| **not separable from zero** | **INCONCLUSIVE.** "Locus does not matter" cannot be separated from "push was constrained" |
| significantly **negative** | **INCONCLUSIVE**, for the same reason. Reported as measured, with no causal reading |

"Significant" means the two-sided 95% bootstrap interval excludes zero (§5).

**The `E − M0` contrast has no such ambiguity** — it compares a locus-corrected term against no term
at all — and is therefore **primary**.

Under no outcome is a "push was constrained" explanation used to convert a negative or null
`E − M1a` result into support for the locus account. The inconclusive verdicts above are final for
this pilot; separating the two factors would require an arm that is not pre-registered here.

## 5. Statistical procedure, fixed in advance

- Paired per-example bootstrap over the 1000 audit examples, **B = 10000**,
  `np.random.default_rng(0)`, one resampled index vector indexing both arms.
- **Estimator reused, not rewritten**: `scripts/dev/make_table1.py:boot`, itself verbatim from
  `scripts/dev/pernorm_ci.py:boot` / `scripts/dev/c5_attribution.py:paired`.
- Both conventions reported and labelled: **`two_sided_95 = [q025, q975]`** (the interval the reading
  rule in §4 uses) and **`lcb_95 = q05`**.
- All three arms are measured on the **same 1000 examples in the same order**, so every contrast is
  paired per example.

## 6. Evaluation harness — REDUCED, and stated as such everywhere

- **APGD-CE only**, at ℓ∞ 8/255, ℓ₂ 0.5, ℓ₁ 12, on the frozen 1k audit subset
  `results/audit/subsets/cifar10_testfinal_1000_seed20260709_v3A.json`
  (sha256 `af0b037aa964b438facaa911c9f6337e9c5233a72efa5453dc5eaa35fe8f8aef`, 1000 class-balanced
  examples), at `val_best` weights. APGD-CE parameters match the audit config exactly:
  `steps=100, restarts=1, seed=20260709`.
- **FAB-T and Square are ABSENT.** These unions are therefore **optimistic** relative to the
  12-attack harness and carry **no black-box gradient-masking check**. This is recorded in the output
  JSON and stated on every table.
- **M0 and M1a are re-measured under this same reduced harness.** Their 12-attack numbers are not
  comparable to E. Because the frozen 1k mask sets already contain the three `apgd_ce_*` per-example
  masks computed with exactly these parameters on exactly this subset, the reduced-harness values for
  M0 and M1a are obtained by **restricting the frozen masks to those three columns** — read-only, no
  re-attack, and exactly identical to re-running a deterministic harness. Arm E is run through the
  same three attacks with the same parameters.
- **This configuration and harness match no arm reported in the paper.** No P1 number may be placed
  in a table alongside a 12-attack number.

### 6.1 Disclosure — what was already seen before this document was committed

During Phase-0 feasibility checking, and **before arm E existed**, the reduced-harness values of the
two *existing* arms were computed from the frozen masks:

| arm | apgd_ce ℓ∞ | ℓ₂ | ℓ₁ | union-3 |
|---|---|---|---|---|
| M0 | 0.4310 | 0.6870 | 0.4800 | **0.4070** |
| M1a | 0.4860 | 0.6870 | 0.5520 | **0.4720** |

These are properties of already-published checkpoints. The quantity this pre-registration constrains —
arm E, and therefore both contrasts — was unknown when this document was written and remains unknown
until E is trained.

## 7. Training recipe — the existing 80-epoch weak-base C5 recipe, VERBATIM

Arm E uses the M1a seed-0 recipe with **exactly one change** (the locus). Every value below is taken
from `scripts/dev/c5_fromscratch.py` and confirmed against
`results/fromscratch/C5/M1a_advneg/seed0/train.json`:

| item | value | source |
|---|---|---|
| epochs | 80 | `:357` |
| batch size | 128 | `:358` |
| optimizer | SGD, lr 0.05, momentum 0.9, weight-decay 5e-4 | `:359`, `:440` |
| schedule | MultiStepLR milestones [70], γ = 0.1 | `:360`, `:441` |
| α, β | 0.5, 0.5 | `:361–362` |
| term warmup | linear `w = min(1, ep/10)` over epochs 0–10 | `:363`, `:460` |
| τ | 0.1 | `:364` |
| CE base | true-MSD (`msd_v0`), 10 steps | `:365`, `:378` |
| glue views | 3 per-norm APGD, 10 iterations | `:370`, `:379` |
| scaffold negatives | other-class **adv** embeddings (`M1a` → `neg_source=adv`) | `:411` |
| augmentation | RandomCrop(32, pad 4) + HFlip + ToTensor | `:295` |
| train split | `train[0:49000]` | `:51` |
| selection split | `train[49000:50000]` | `:52` |
| selection rule | val worst-union = AND over the 3 norms, APGD `n_iter=20` from the clean start; save `val_best` when strictly greater | `:262–289`, `:649–650`, `:684–685` |
| seed | 0 | — |

**The single change:** both the glue and the scaffold term are computed on `normalize(f)` instead of
on `normalize(head(f))`, where `f` is the pooled 512-d **post-ReLU** encoder output the linear
classifier consumes — identical to `t2_geometry.Enc.features`. Normalisation is retained because the
loss is a cosine and `pos_sim` is a plain dot product; cosine on `f` equals the dot product on
`normalize(f)`, and is the same metric T2 measured.

### 7.1 Constraints fixed in advance — what may NOT be done to rescue arm E

The non-negativity of `f` is a **known, recorded property**, not a defect to engineer around. For arm
E it is **not permitted** to: insert a signed projection; retune τ; switch the push branch to a
Euclidean distance; remove or move the final ReLU; change α or β; or change any other recipe value in
§7. Arm E changes the locus and nothing else. If the run diverges or produces NaN, it is **reported
and stopped**, not retuned.

### 7.2 The head must receive no gradient

Under the locus switch `model.head` is never called in the loss path, so autograd produces no
gradient for its parameters, `opt.zero_grad()` leaves `p.grad` as `None`, and SGD skips such
parameters entirely — no gradient step, no momentum, no weight decay. This is **asserted, not
assumed**:

1. every head parameter has `.grad is None` after each backward pass;
2. the head `state_dict` at the end of training is **bitwise identical** to its snapshot at
   initialisation;
3. `head[2].weight.std()` is reported at the end and must equal the initialisation value
   **0.02549** — the same quantity and the same value T2b used to certify an untrained head.

The h-space diagnostics that call `model.embed` (`:280–281`, `:518–519`, `:695`) are `no_grad`
read-outs; for arm E they are disabled or redirected to `f`, so the head is never touched at all.

## 8. Per-epoch training log, fixed in advance

Logged every epoch: total loss, **glue and scaffold separately**, the val proxy (worst-union), and —
computed on `f` — the mean cosine between (i) each adversarial view and its clean anchor, and
(ii) randomly paired different-class examples. The second pair shows directly whether the term is
achieving anything in-sample **in the space T2 found moving the wrong way**.

## 9. Deviations log

*(empty at commit time; any deviation is appended here with its reason and date)*

## 10. Outputs

`results/analysis/P1_locus/p1_locus.json` — for each of the three arms: checkpoint path and sha256,
`val_best` epoch, and clean / union / per-norm accuracies at 1k under the reduced harness; both
contrasts under both CI conventions; the per-epoch training curves; and an explicit note that this
configuration and harness match no arm reported in the paper.

Training artifacts are written only under `results/fromscratch/P1_locus/`; analysis only under
`results/analysis/P1_locus/`. `results/main/` and every existing checkpoint are read-only.
`scripts/dev/c5_fromscratch.py` is not edited in place: the locus switch is added as a new option
whose default reproduces current behaviour exactly, so every prior arm remains reproducible.

## 11. Known limitations, acknowledged in advance

- **One seed, one arm.** Seed-to-seed variation of arm E is not measured. The existing arms have
  seeds 2/3 available; arm E does not.
- **Reduced harness** (§6): three white-box attacks, no black-box check, optimistic unions.
- **`E − M1a` is confounded by construction** (§4) and can only ever return "evidence for locus" or
  "inconclusive".
- **M0 seed 0 has no local training record** — the checkpoint was downloaded (dossier §, "no local
  `train.json`"). It is nonetheless exactly the checkpoint the paper's M0 numbers come from, verified
  by sha256 against the frozen mask metadata.
- Compute is not matched between E and M0: E crafts 1 MSD + 3 APGD views per step, M0 crafts 1. This
  is the same accounting caveat the existing M1a-vs-M0 contrast carries, and is not introduced by P1.
